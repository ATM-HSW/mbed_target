//
// File: ert_main.cpp
//
// Code generated for Simulink model 'nucleo_f446_blinky'.
//
// Model version                  : 1.12
// Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
// C/C++ source code generated on : Tue Jul 19 17:33:34 2016
//
// Target selection: mbed.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "nucleo_f446_blinky.h"
#include "mbed.h"
#include "rtos.h"
#define STEP_SIZE_US                   1000.0F                   // Sample Time in microseconds 
#define STEP_SIZE_MS                   1.0F                      // and in milliseconds 
#if (defined(TARGET_STM32L053R8) || defined(TARGET_STM32L053C8)) && defined(TOOLCHAIN_GCC)
#define STACK_SIZE                     DEFAULT_STACK_SIZE/2
#elif (defined(TARGET_STM32F030R8) || defined(TARGET_STM32F070RB) || defined(TARGET_STM32F042K6)) && defined(TOOLCHAIN_GCC)
#define STACK_SIZE                     DEFAULT_STACK_SIZE/2
#else
#define STACK_SIZE                     DEFAULT_STACK_SIZE
#endif

osThreadId step_id;
void step_thread(void const *param)
{
  step_id = Thread::gettid();
  while (1) {
    Thread::signal_wait(0x1,osWaitForever);
    nucleo_f446_blinky_step();

    // Get model outputs here
  }
}

void step_callback(void const *param)
{
  osSignalSet(step_id, 0x1);
}

// with RTOS
int main(void)
{
  Thread step_1_thread(step_thread, NULL, osPriorityNormal, STACK_SIZE);
  RtosTimer step_1_timer(step_callback, osTimerPeriodic, (void *)0);

  // initialize model
  nucleo_f446_blinky_initialize();

  // start Timer for main step function
  step_1_timer.start(STEP_SIZE_MS);

  // main task waits forever
  Thread::wait(osWaitForever);

  // deinitialize model
  nucleo_f446_blinky_terminate();
  return 0;
}

//
// File trailer for generated code.
//
// [EOF]
//
